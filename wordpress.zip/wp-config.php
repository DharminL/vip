<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'vip_ind');

/** MySQL database username */
define('DB_USER', 'root');

/** MySQL database password */
define('DB_PASSWORD', '');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'e_qPk](~l^o_4z%v/Rg>=isXkQvocGb|F@axug((C (3DlGBn*!&E,$}n|9b/1G$');
define('SECURE_AUTH_KEY',  'U6)P twjfuAo,N|LBILr7UB^E`x~MD<wN|`^ePr?`yQl5X07,>_e6KRN$p5Cc+!E');
define('LOGGED_IN_KEY',    ')lW;*Q1phqNo!!LO1;S>l#W%%~qN!93gGb8L.<<=T.aZZC[F`7tFeQ5Je>V5ag&3');
define('NONCE_KEY',        '.[h</he9qPh[mbm#Wr0fn%!<,)ZeXm~ p d?[QPC_)_,N@HZ1XZ5JET;)DVa{XL1');
define('AUTH_SALT',        'HXw HKV_c1jwIPRFBD?|vJdS-9` od2q*}%%x{~(eiXB3:PhN:n6BWtxEKuu:p15');
define('SECURE_AUTH_SALT', '(nY#T3zS/aii#_>eR)K+7&1+cPYn@JYr}(sJ|? :6,E%NlcEEmdApKWc/]YIWGXd');
define('LOGGED_IN_SALT',   'p31/m^4IS}@c;.ZO>N1nP/{<;wkux#/le<7VZrzkrnB3$Q<1<lFwdDJ|}DCc3;PJ');
define('NONCE_SALT',       '^Y_5XEY&+YiOfIs3IkV5R&un= -uUdv|k(_>S=X7zz(-69#YCV5L_}%,9A7-_:ag');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
